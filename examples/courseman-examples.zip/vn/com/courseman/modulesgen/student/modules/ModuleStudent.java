package vn.com.courseman.modulesgen.student.modules;

import domainapp.basics.model.meta.module.ModuleDescriptor;
import domainapp.basics.model.meta.module.view.AttributeDesc;
import java.util.Collection;
import vn.com.courseman.modulesgen.sclass.model.SClass;
import vn.com.courseman.modulesgen.sclassregist.model.SClassRegistration;
import vn.com.courseman.modulesgen.coursemodule.model.CourseModule;
import vn.com.courseman.modulesgen.enrolment.model.Enrolment;
import vn.com.courseman.modulesgen.enrolmentmgmt.model.EnrolmentMgmt;

@ModuleDescriptor(name = "ModuleStudent", modelDesc = @domainapp.basics.model.meta.module.model.ModelDesc(model = vn.com.courseman.modulesgen.student.model.Student.class), viewDesc = @domainapp.basics.model.meta.module.ViewDesc(formTitle = "Form: Student", imageIcon = "Student.png", domainClassLabel = "Student", view = domainapp.basics.core.View.class), controllerDesc = @domainapp.basics.model.meta.module.controller.ControllerDesc())
public class ModuleStudent {

    @AttributeDesc(label = "title")
    private String title;

    @AttributeDesc(label = "id")
    private int id;

    @AttributeDesc(label = "name")
    private String name;

    @AttributeDesc(label = "helpRequested")
    private boolean helpRequested;

    @AttributeDesc(label = "sclasses")
    private Collection<SClass> sclasses;

    @AttributeDesc(label = "classRegists")
    private Collection<SClassRegistration> classRegists;

    @AttributeDesc(label = "modules")
    private Collection<CourseModule> modules;

    @AttributeDesc(label = "enrolments")
    private Collection<Enrolment> enrolments;

    @AttributeDesc(label = "enrolmentMgmt2")
    private EnrolmentMgmt enrolmentMgmt2;
}
