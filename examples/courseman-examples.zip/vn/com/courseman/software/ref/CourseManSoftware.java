package vn.com.courseman.software.ref;

import domainapp.basics.exceptions.DataSourceException;
import domainapp.basics.exceptions.NotFoundException;
import domainapp.software.Software;
import domainapp.software.SoftwareFactory;
import vn.com.courseman.software.config.ref.CourseManConfigClass;

/**
 * @overview 
 *
 * @author Duc Minh Le (ducmle)
 *
 * @version 
 */
public class CourseManSoftware {
  
  public static void main(String[] args) throws NotFoundException, DataSourceException {
    // create a default software needed to run the activity
    Software sw = SoftwareFactory.createSoftwareWithMemoryBasedConfig(CourseManConfigClass.class);
    
    // run the software to show the main GUI
    System.out.printf("Running %s...%n", sw);
    
    sw.run();
  }
}
