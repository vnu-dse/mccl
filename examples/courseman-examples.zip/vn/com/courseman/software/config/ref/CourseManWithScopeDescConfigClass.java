/**
 * 
 */
package vn.com.courseman.software.config.ref;

import domainapp.basics.model.config.Configuration.Language;
import domainapp.basics.model.config.dodm.OsmConfig.ConnectionType;
import domainapp.core.dodm.dom.DOM;
import domainapp.core.dodm.dsm.DSM;
import domainapp.core.dodm.osm.postgresql.PostgreSQLOSM;
import domainapp.model.meta.app.DSDesc;
import domainapp.model.meta.app.OrgDesc;
import domainapp.model.meta.app.SecurityDesc;
import domainapp.model.meta.app.SysSetUpDesc;
import domainapp.model.meta.app.SystemDesc;
import domainapp.setup.SetUpConfig;
import vn.com.courseman.modulesref.ModuleMain;
import vn.com.courseman.modulesref.enrolmentmgmt.ModuleEnrolmentMgmt;
import vn.com.courseman.modulesref.enrolmentmgmt.ModuleEnrolmentMgmtWithCustomScopeDescriptor;
import vn.com.courseman.modulesref.student.ModuleStudent;

/**
 * @overview 
 *  The system class of the CourseMan application.
 * @author dmle
 * @version 4.0
 */
@SystemDesc(
    appName="CourseMan",
    splashScreenLogo="coursemanapplogo.jpg",
    language=Language.English,
    orgDesc=@OrgDesc(
        name="Faculty of IT",
        address="K1m9 Đường Nguyễn Trãi, Quận Thanh Xuân", 
        logo="hanu.gif", 
        url="http://fit.hanu.edu.vn"
    ), 
    dsDesc=@DSDesc(
        type="postgresql", 
        dsUrl="//localhost:5432/domainds", 
        user="admin",
        password="password",
        dsmType=DSM.class,
        domType=DOM.class,
        osmType=PostgreSQLOSM.class,
        connType=ConnectionType.Client
    ), 
    modules={         
      ModuleMain.class,  // main
      // data
      ModuleEnrolmentMgmtWithCustomScopeDescriptor.class,
      // IMPORTANT: needed to indicate that we need to serialise data!!!!
      ModuleStudent.class 
    },
    sysModules={}, 
    setUpDesc=@SysSetUpDesc(
      setUpConfigType=SetUpConfig.class
    ),
    securityDesc=@SecurityDesc(
      isEnabled=false
    )
)
public class CourseManWithScopeDescConfigClass {
  // empty
}
